

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class ExpenseTrackerFrame extends JFrame {

    private JTextField amountField, dateField, budgetField;
    private JComboBox<String> categoryBox;
    private JTextArea descriptionArea, expenseDisplayArea;
    private JButton addButton, saveBudgetButton, showGraphButton;
    private JLabel remainingMoneyLabel;
    private String username;
    private double remainingMoney;
    
    
    private static final String EXPENSES_FILE = "expenses.txt";  
    private static final String BUDGET_FILE_FORMAT = "budget_%s.txt";  
    private static final String REMAINING_MONEY_FILE_FORMAT = "remainingMoney_%s.txt";

    public ExpenseTrackerFrame(String username) {
        this.username = username;
        setTitle("Expense Tracker - " + username);
        setSize(500,700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
        loadExpenses();
        loadBudget(); 
        loadRemainingMoney();  
        setVisible(true);
    }

    /*private void initComponents() {
       
        setLayout(new BorderLayout());

        
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 5, 5));

        JLabel amt=new JLabel("Amount:");
		amt.setForeground(Color.BLUE);
		formPanel.add(amt);
        amountField = new JTextField();
        formPanel.add(amountField);

        JLabel cat=new JLabel("Category:");
		cat.setForeground(Color.BLUE);
		formPanel.add(cat);
        String[] categories = {"Food", "Transportation", "Entertainment", "Others"};
        categoryBox = new JComboBox<>(categories);
        formPanel.add(categoryBox);

        JLabel dat=new JLabel("Date (YYYY-MM-DD):");
		dat.setForeground(Color.BLUE);
		formPanel.add(dat);
        dateField = new JTextField();
        formPanel.add(dateField);

        JLabel des=new JLabel("Description:");
		des.setForeground(Color.BLUE);
		formPanel.add(des);
        descriptionArea = new JTextArea(2, 10);
        formPanel.add(new JScrollPane(descriptionArea));

        addButton = new JButton("Add Expense");
		addButton.setBackground(Color.PINK);
        formPanel.add(addButton);

        JLabel bud=new JLabel("Budget:");
		bud.setForeground(Color.BLUE);
		formPanel.add(bud);
        budgetField = new JTextField();
        formPanel.add(budgetField);
        
        saveBudgetButton = new JButton("Save Budget");
        saveBudgetButton.setBackground(Color.PINK);
		formPanel.add(saveBudgetButton);

        showGraphButton = new JButton("Show Graph");
        showGraphButton.setBackground(Color.PINK);
		formPanel.add(showGraphButton);

        add(formPanel, BorderLayout.NORTH);

        
        expenseDisplayArea = new JTextArea();
		expenseDisplayArea.setBackground(Color.ORANGE);
        expenseDisplayArea.setEditable(false);
        add(new JScrollPane(expenseDisplayArea), BorderLayout.CENTER);

        remainingMoneyLabel = new JLabel("Remaining Money: $0.00");
		remainingMoneyLabel.setForeground(Color.RED);
		remainingMoneyLabel.setFont(new Font(remainingMoneyLabel.getFont().getName(),remainingMoneyLabel.getFont().getStyle(),25));
        add(remainingMoneyLabel, BorderLayout.SOUTH); 
        JButton signOutButton = new JButton("Sign Out");
        signOutButton.setBackground(Color.PINK);
		formPanel.add(signOutButton);

        
        addButton.addActionListener(e -> addExpense());
        saveBudgetButton.addActionListener(e -> saveBudget());
        showGraphButton.addActionListener(e -> showGraph());
         signOutButton.addActionListener(e -> {
            dispose(); 
            new LoginFrame().createAndShowGUI(); 
        });
    }*/
	
	private void initComponents() {
    setLayout(null); 

    
    ImageIcon icon = new ImageIcon("download2.jpg"); 
    JLabel imageLabel = new JLabel(icon);
    imageLabel.setBounds(130, 510, 200, 150); 
    add(imageLabel);
	
	


	
	getContentPane().setBackground(Color.CYAN);
	JLabel amt = new JLabel("Amount:");
    amt.setForeground(Color.BLUE);
    amt.setBounds(30, 20, 150, 25);
    add(amt);

    amountField = new JTextField();
    amountField.setBounds(180, 20, 200, 25);
    add(amountField);

    JLabel cat = new JLabel("Category:");
    cat.setForeground(Color.BLUE);
    cat.setBounds(30, 60, 150, 25);
    add(cat);

    String[] categories = {"Food", "Transportation", "Entertainment", "Others"};
    categoryBox = new JComboBox<>(categories);
    categoryBox.setBounds(180, 60, 200, 25);
	categoryBox.setBackground(Color.PINK);
    add(categoryBox);

    JLabel dat = new JLabel("Date (YYYY-MM-DD):");
    dat.setForeground(Color.BLUE);
    dat.setBounds(30, 100, 150, 25);
    add(dat);

    dateField = new JTextField();
    dateField.setBounds(180, 100, 200, 25);
    add(dateField);

    JLabel des = new JLabel("Description:");
    des.setForeground(Color.BLUE);
    des.setBounds(30, 140, 150, 25);
    add(des);

    descriptionArea = new JTextArea();
    JScrollPane descriptionScroll = new JScrollPane(descriptionArea);
    descriptionScroll.setBounds(180, 140, 200, 50);
    add(descriptionScroll);

    JLabel bud = new JLabel("Budget:");
    bud.setForeground(Color.BLUE);
    bud.setBounds(30, 200, 150, 25);
    add(bud);

    budgetField = new JTextField();
    budgetField.setBounds(180, 200, 200, 25);
    add(budgetField);

    addButton = new JButton("Add Expense");
    addButton.setBackground(Color.PINK);
    addButton.setBounds(30, 240, 150, 30);
    add(addButton);

    saveBudgetButton = new JButton("Save Budget");
    saveBudgetButton.setBackground(Color.PINK);
    saveBudgetButton.setBounds(230, 240, 150, 30);
    add(saveBudgetButton);

    showGraphButton = new JButton("Show Graph");
    showGraphButton.setBackground(Color.PINK);
    showGraphButton.setBounds(30, 280, 150, 30);
    add(showGraphButton);

    JButton signOutButton = new JButton("Sign Out");
    signOutButton.setBackground(Color.PINK);
    signOutButton.setBounds(230, 280, 150, 30);
    add(signOutButton);

    expenseDisplayArea = new JTextArea();
    expenseDisplayArea.setEditable(false);
    expenseDisplayArea.setBackground(Color.ORANGE);
    JScrollPane expenseScroll = new JScrollPane(expenseDisplayArea);
    expenseScroll.setBounds(30, 320, 400, 150);
    add(expenseScroll);

    remainingMoneyLabel = new JLabel("Remaining Money: $0.00");
    remainingMoneyLabel.setForeground(Color.RED);
    remainingMoneyLabel.setFont(new Font(remainingMoneyLabel.getFont().getName(), remainingMoneyLabel.getFont().getStyle(), 25));
    remainingMoneyLabel.setBounds(30, 480, 400, 30);
    add(remainingMoneyLabel);

    // Add action listeners
    addButton.addActionListener(e -> addExpense());
    saveBudgetButton.addActionListener(e -> saveBudget());
    showGraphButton.addActionListener(e -> showGraph());
    signOutButton.addActionListener(e -> {
        dispose();
        new LoginFrame().createAndShowGUI();
    });
}


    private void addExpense() {
        String amountText = amountField.getText();
        String category = (String) categoryBox.getSelectedItem();
        String date = dateField.getText();
        String description = descriptionArea.getText();

        if (amountText.isEmpty() || date.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Amount and Date are required!");
            return;
        }

        try {
            double amount = Double.parseDouble(amountText);
            if (remainingMoney - amount < 0) {
                JOptionPane.showMessageDialog(this, "You don't have enough budget left!");
                return;
            }

            String line = username + "," + category + "," + amount + "," + date + "," + description;

           
            BufferedWriter writer = new BufferedWriter(new FileWriter(EXPENSES_FILE, true));
            writer.write(line);
            writer.newLine();
            writer.close();

            
            remainingMoney -= amount;
            updateRemainingMoneyLabel();

           
            saveRemainingMoney();

           
            JOptionPane.showMessageDialog(this, "Expense added successfully!");

          
            amountField.setText("");
            dateField.setText("");
            descriptionArea.setText("");

            
            loadExpenses();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid amount entered!");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving expense!");
        }
    }

    private void loadExpenses() {
        expenseDisplayArea.setText(""); 
        try {
            BufferedReader reader = new BufferedReader(new FileReader(EXPENSES_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(username + ",")) {
                    
                    expenseDisplayArea.append(line + "\n");
                }
            }
            reader.close();
        } catch (IOException e) {
            
        }
    }

    private void loadBudget() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(String.format(BUDGET_FILE_FORMAT, username)));
            String line = reader.readLine();
            if (line != null) {
                remainingMoney = Double.parseDouble(line);
            } else {
                remainingMoney = 0.0;
            }
            reader.close();
            budgetField.setText(String.valueOf(remainingMoney)); 
            updateRemainingMoneyLabel();  
        } catch (IOException e) {
         
            remainingMoney = 0.0;
        }
    }

    private void loadRemainingMoney() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(String.format(REMAINING_MONEY_FILE_FORMAT, username)));
            String line = reader.readLine();
            if (line != null) {
                remainingMoney = Double.parseDouble(line);
            } else {
                remainingMoney = 0.0;
            }
            reader.close();
            updateRemainingMoneyLabel();
        } catch (IOException e) {
            
            remainingMoney = 0.0;
        }
    }

    private void saveBudget() {
        try {
            double budget = Double.parseDouble(budgetField.getText());
            remainingMoney = budget;

            
            BufferedWriter writer = new BufferedWriter(new FileWriter(String.format(BUDGET_FILE_FORMAT, username)));
            writer.write(String.valueOf(budget));
            writer.close();

            
            saveRemainingMoney();

            JOptionPane.showMessageDialog(this, "Budget saved successfully!");
            updateRemainingMoneyLabel();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid budget entered!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving budget!");
        }
    }

    private void saveRemainingMoney() {
        try {
            
            BufferedWriter writer = new BufferedWriter(new FileWriter(String.format(REMAINING_MONEY_FILE_FORMAT, username)));
            writer.write(String.valueOf(remainingMoney));
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving remaining money!");
        }
    }

    private void updateRemainingMoneyLabel() {
        remainingMoneyLabel.setText("Remaining Money: $" + String.format("%.2f", remainingMoney));
    }

    
    private void showGraph() {
        
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(EXPENSES_FILE));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(username + ",")) {
                    String[] parts = line.split(",");
                    String date = parts[3];
                    double amount = Double.parseDouble(parts[2]);
                    dataset.addValue(amount, "Expenses", date); 
                }
            }
            reader.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading expenses for the graph!");
        }

        
        JFreeChart chart = ChartFactory.createBarChart(
                "Expenses Over Time",  
                "Date",                
                "Amount",              
                dataset,               
                PlotOrientation.VERTICAL, 
                true,                  
                true,                 
                false                  
        );

        
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(800, 600));
        JFrame chartFrame = new JFrame("Expense Graph");
        chartFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        chartFrame.getContentPane().add(chartPanel);
        chartFrame.pack();
        chartFrame.setVisible(true);
    }
}
