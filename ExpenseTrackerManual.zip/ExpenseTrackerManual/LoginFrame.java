

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.security.MessageDigest;

public class LoginFrame {
    private JFrame frame;
    private JTextField userText;
    private JPasswordField passwordField;

    /*public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginFrame().createAndShowGUI());
    }*/

    public void createAndShowGUI() {
        frame = new JFrame("Login");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // UI Components
        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 50, 100, 30);
		userLabel.setForeground(Color.RED);
        userText = new JTextField();
        userText.setBounds(150, 50, 200, 30);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 100, 100, 30);
		passwordLabel.setForeground(Color.RED);
        passwordField = new JPasswordField();
        passwordField.setBounds(150, 100, 200, 30);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(50, 150, 100, 30);
		loginButton.setBackground(Color.BLUE);
        JButton registerButton = new JButton("Register");
        registerButton.setBounds(200, 150, 100, 30);
		registerButton.setBackground(Color.GREEN);

        // Add Components to Frame
        frame.add(userLabel);
        frame.add(userText);
        frame.add(passwordLabel);
        frame.add(passwordField);
        frame.add(loginButton);
        frame.add(registerButton);

        // Login Action
        loginButton.addActionListener(e -> loginAction());

        // Register Action
        registerButton.addActionListener(e -> registerAction());
        frame.getContentPane().setBackground(Color.WHITE);
        frame.setVisible(true);
    }

    // Login action
    public void loginAction() {
    String username = userText.getText();
    String password = new String(passwordField.getPassword());

    if (checkLogin(username, password)) {
        JOptionPane.showMessageDialog(frame, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
        frame.dispose(); // Close the login window
        new ExpenseTrackerFrame(username); // Open the main expense tracker window
    } else {
        JOptionPane.showMessageDialog(frame, "Invalid Username or Password", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }


    // Register action
    public void registerAction() {
        String username = userText.getText();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Username and password cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (userExists(username)) {
            JOptionPane.showMessageDialog(frame, "Username already exists", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        registerUser(username, password);
        JOptionPane.showMessageDialog(frame, "Registration Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    // Password hashing function
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Register user by saving username and hashed password to users.txt
    private void registerUser(String username, String password) {
        String hashedPassword = hashPassword(password);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
            writer.write(username + ":" + hashedPassword);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Check if username exists in users.txt
    private boolean userExists(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(":");
                if (userData[0].equals(username)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Check login credentials
    private boolean checkLogin(String username, String password) {
        String hashedPassword = hashPassword(password);
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(":");
                if (userData[0].equals(username) && userData[1].equals(hashedPassword)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}
